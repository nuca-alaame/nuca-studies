<?php

return [
    'anourvalar/eloquent-serialize' => [
        'aliases' => [
            'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
        ],
    ],
    'bezhansalleh/filament-shield' => [
        'aliases' => [
            'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
        ],
        'providers' => [
            0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
        ],
    ],
    'blade-ui-kit/blade-heroicons' => [
        'providers' => [
            0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
        ],
    ],
    'blade-ui-kit/blade-icons' => [
        'providers' => [
            0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
        ],
    ],
    'filament/actions' => [
        'providers' => [
            0 => 'Filament\\Actions\\ActionsServiceProvider',
        ],
    ],
    'filament/filament' => [
        'providers' => [
            0 => 'Filament\\FilamentServiceProvider',
        ],
    ],
    'filament/forms' => [
        'providers' => [
            0 => 'Filament\\Forms\\FormsServiceProvider',
        ],
    ],
    'filament/infolists' => [
        'providers' => [
            0 => 'Filament\\Infolists\\InfolistsServiceProvider',
        ],
    ],
    'filament/notifications' => [
        'providers' => [
            0 => 'Filament\\Notifications\\NotificationsServiceProvider',
        ],
    ],
    'filament/support' => [
        'providers' => [
            0 => 'Filament\\Support\\SupportServiceProvider',
        ],
    ],
    'filament/tables' => [
        'providers' => [
            0 => 'Filament\\Tables\\TablesServiceProvider',
        ],
    ],
    'filament/widgets' => [
        'providers' => [
            0 => 'Filament\\Widgets\\WidgetsServiceProvider',
        ],
    ],
    'kirschbaum-development/eloquent-power-joins' => [
        'providers' => [
            0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
        ],
    ],
    'laravel/pail' => [
        'providers' => [
            0 => 'Laravel\\Pail\\PailServiceProvider',
        ],
    ],
    'laravel/sail' => [
        'providers' => [
            0 => 'Laravel\\Sail\\SailServiceProvider',
        ],
    ],
    'laravel/tinker' => [
        'providers' => [
            0 => 'Laravel\\Tinker\\TinkerServiceProvider',
        ],
    ],
    'livewire/livewire' => [
        'aliases' => [
            'Livewire' => 'Livewire\\Livewire',
        ],
        'providers' => [
            0 => 'Livewire\\LivewireServiceProvider',
        ],
    ],
    'nesbot/carbon' => [
        'providers' => [
            0 => 'Carbon\\Laravel\\ServiceProvider',
        ],
    ],
    'nunomaduro/collision' => [
        'providers' => [
            0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
        ],
    ],
    'nunomaduro/termwind' => [
        'providers' => [
            0 => 'Termwind\\Laravel\\TermwindServiceProvider',
        ],
    ],
    'orangehill/iseed' => [
        'providers' => [
            0 => 'Orangehill\\Iseed\\IseedServiceProvider',
        ],
    ],
    'pestphp/pest-plugin-laravel' => [
        'providers' => [
            0 => 'Pest\\Laravel\\PestServiceProvider',
        ],
    ],
    'ryangjchandler/blade-capture-directive' => [
        'aliases' => [
            'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
        ],
        'providers' => [
            0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
        ],
    ],
    'spatie/laravel-permission' => [
        'providers' => [
            0 => 'Spatie\\Permission\\PermissionServiceProvider',
        ],
    ],
];
