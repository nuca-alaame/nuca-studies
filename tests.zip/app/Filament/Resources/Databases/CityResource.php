<?php

namespace App\Filament\Resources\Databases;

use App\Filament\Resources\Databases\CityResource\Pages;
use App\Filament\Resources\Databases\CityResource\RelationManagers;
use App\Models\City;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class CityResource extends Resource
{
    protected static ?string $model = City::class;

    protected static ?string $navigationIcon = 'heroicon-s-map-pin';

    protected static ?string $navigationGroup = 'قواعد البيانات';

    protected static ?string $label = 'المدينة';

    protected static ?string $modelLabel = 'مدينة';

    protected static ?string $pluralLabel = 'المدن';

    protected static ?string $navigationLabel = 'قائمة المدن';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make()
                    ->schema([
                        Forms\Components\TextInput::make('name')->required()->label('اسم المدينة'),
                        Forms\Components\Select::make('sector_id')->relationship('sector', 'name')->required()->label('القطاع'),

                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('المدينة')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('sector.name')->label('القطاع')->default('-')->searchable()->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('sector_id')->relationship('sector', 'name')->label('القطاع'),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListCities::route('/'),
            'create' => Pages\CreateCity::route('/create'),
            'edit' => Pages\EditCity::route('/{record}/edit'),
        ];
    }

    public static function getNavigationSort(): ?int
    {
        return 1;
    }
}